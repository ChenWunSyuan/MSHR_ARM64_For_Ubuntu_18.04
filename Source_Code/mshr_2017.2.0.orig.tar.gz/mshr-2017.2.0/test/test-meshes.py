from dolfin import *
import mshr

# Unit sphere mesh
m = mshr.UnitSphereMesh(4)
m = mshr.UnitSphereMesh(10) 
