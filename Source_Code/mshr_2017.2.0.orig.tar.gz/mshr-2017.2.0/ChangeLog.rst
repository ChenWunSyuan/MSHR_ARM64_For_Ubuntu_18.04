Changelog
=========

2017.2.0 (2017-11-30)
---------------------

- Nothing changed yet

2017.1.0 (2017-05-11)
---------------------

- Bugfixes

2016.2.0 (2016-11-30)
---------------------

- Improvements and bugfixes
- Upgrade to CGAL 4.9 and use CGAL as header only library

2016.1.0 (2016-06-23)
---------------------

- Major improvements, in particular boundary conditions

1.6.0 (2015-07-28)
------------------

- Upgrade to CGAL 4.6
- Add more demos
- Faster and more memory efficient implementation of csg operations
  with -DENABLE_EXPERIMENTAL=True
- Bugfixes and cleanups

1.5.0 (2015-02-04)
------------------

- Initial release of mshr.
