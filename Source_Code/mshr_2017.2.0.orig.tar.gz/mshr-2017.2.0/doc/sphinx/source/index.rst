mshr documentation
==================

Mshr manual is located on `Bitbucket wiki
<https://bitbucket.org/fenics-project/mshr/wiki/Home>`_.
It is waiting for porting to Read the Docs. Contributions
are welcome and first best discussed on `FEniCS Slack
#documentation channel
<https://fenicsproject.slack.com/messages/C1AGB4402/>`_,
see `instruction for joining <https://fenicsproject.org/community/>`_.

Automatically generated API documentation is not available yet.
The approach from DOLFIN could possibly be ported to mshr too.
Again, contributions are welcome.

Contents:

.. toctree::
   :maxdepth: 1

   ChangeLog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
